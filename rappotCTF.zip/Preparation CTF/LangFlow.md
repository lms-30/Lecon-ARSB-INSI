# `validate/code`Exécution de code à distance avant authentification via l'API Langflow (CVE-2025-3248)

[](https://github.com/vulhub/vulhub/tree/master/langflow/CVE-2025-3248#langflow-validatecode-api-pre-auth-remote-code-execution-cve-2025-3248)

[中文版本 (version chinoise)](https://github.com/vulhub/vulhub/blob/master/langflow/CVE-2025-3248/README.zh-cn.md)

Langflow est un outil open source populaire pour la création de flux de travail d'IA multi-agents, offrant une interface web basée sur Python pour construire visuellement des agents et des pipelines pilotés par l'IA.

Une vulnérabilité critique d'exécution de code à distance non authentifiée (CVE-2025-3248) existe dans Langflow, versions antérieures à 1.3.0. Un point d'accès vulnérable `/api/v1/validate/code`tente de valider le code Python soumis par l'utilisateur en l'analysant avec le `ast`module et en exécutant les définitions de fonctions `exec`. Cependant, les décorateurs Python et les expressions d'arguments par défaut sont également exécutés lors de la définition des fonctions, ce qui permet d'injecter du code arbitraire via ces fonctionnalités.

Les attaquants peuvent exploiter cette vulnérabilité en envoyant une définition de fonction spécialement conçue avec un décorateur malveillant ou un argument par défaut, ce qui permet l'exécution de code en tant qu'utilisateur du serveur.

Références :

- [https://horizon3.ai/attack-research/disclosures/unsafe-at-any-speed-abusing-python-exec-for-unauth-rce-in-langflow-ai/](https://horizon3.ai/attack-research/disclosures/unsafe-at-any-speed-abusing-python-exec-for-unauth-rce-in-langflow-ai/)
- [https://github.com/langflow-ai/langflow/releases/tag/1.3.0](https://github.com/langflow-ai/langflow/releases/tag/1.3.0)
- [langflow-ai/langflow#6911](https://github.com/langflow-ai/langflow/pull/6911)