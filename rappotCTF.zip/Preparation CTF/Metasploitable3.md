### vulnérabilité trouvées 
warning[]=NONE|Version of Lynis very outdated|
warning[]=FILE-6354|Found 2 files in /tmp which are older than 90 days|
warning[]=FIRE-4512|iptables module(s) loaded, but no rules active|
warning[]=LOGG-2130|No syslog daemon found|
warning[]=LOGG-2138|klogd is not running, which could lead to missing kernel messages in log files|


After NULL UDP avahi packet DoS (CVE-2011-1002).