# Exécution de code à distance non authentifiée dans Erlang/OTP SSH (CVE-2025-32433)

[](https://github.com/vulhub/vulhub/tree/master/erlang/CVE-2025-32433#unauthenticated-remote-code-execution-in-erlangotp-ssh-cve-2025-32433)

[中文版本 (version chinoise)](https://github.com/vulhub/vulhub/blob/master/erlang/CVE-2025-32433/README.zh-cn.md)

Erlang/OTP SSH est le composant serveur SSH intégré de la plateforme Erlang/OTP.

Une vulnérabilité critique a été découverte dans le serveur SSH Erlang/OTP, permettant à des attaquants d'exécuter à distance des commandes système arbitraires sans authentification en créant des messages spécifiques du protocole SSH. Les versions concernées sont OTP-27.3.2 et antérieures, OTP-26.2.5.10 et antérieures, et OTP-25.3.2.19 et antérieures.

- [https://github.com/erlang/otp/security/advisories/GHSA-37cp-fgq5-7wc2](https://github.com/erlang/otp/security/advisories/GHSA-37cp-fgq5-7wc2)
- [https://github.com/erlang/otp/commit/6eef04130afc8b0ccb63c9a0d8650209cf54892f#diff-ceeb1aeeb602e1424c13d9da9383e0782f65869d6e64e015c194145b1a64edcd](https://github.com/erlang/otp/commit/6eef04130afc8b0ccb63c9a0d8650209cf54892f#diff-ceeb1aeeb602e1424c13d9da9383e0782f65869d6e64e015c194145b1a64edcd)
- [https://github.com/ProDefense/CVE-2025-32433](https://github.com/ProDefense/CVE-2025-32433)
- [https://datatracker.ietf.org/doc/html/rfc4254](https://datatracker.ietf.org/doc/html/rfc4254)