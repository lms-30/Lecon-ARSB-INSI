# Injection SQL post-authentification dans le panneau de contrôle 1Panel (CVE-2024-39907)

1Panel est un panneau de contrôle de gestion de serveurs Linux basé sur le Web qui fournit une interface graphique pour l'administration du serveur.

CVE-2024-39907 désigne un ensemble de vulnérabilités d'injection SQL présentes dans le panneau de contrôle 1Panel. Ces vulnérabilités affectent plusieurs interfaces de 1Panel, et un filtrage insuffisant pourrait permettre à des attaquants d'effectuer des écritures arbitraires dans les fichiers et, à terme, d'exécuter du code à distance (RCE). Cette vulnérabilité affecte les versions de 1Panel antérieures à la version 1.10.9-lts et a été corrigée dans la version 1.10.12-lts.

Références :

- [https://github.com/projectdiscovery/nuclei-templates/blob/main/http/cves/2024/CVE-2024-39907.yaml](https://github.com/projectdiscovery/nuclei-templates/blob/main/http/cves/2024/CVE-2024-39907.yaml)
- [https://github.com/1Panel-dev/1Panel/security/advisories/GHSA-5grx-v727-qmq6](https://github.com/1Panel-dev/1Panel/security/advisories/GHSA-5grx-v727-qmq6)
- [https://hub.docker.com/r/moelin/1panel](https://hub.docker.com/r/moelin/1panel)