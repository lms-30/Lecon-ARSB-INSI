# Exécution de code à distance non authentifiée via Kubernetes Ingress-NGINX (CVE-2025-1974)

[](https://github.com/vulhub/vulhub/tree/master/ingress-nginx/CVE-2025-1974#kubernetes-ingress-nginx-unauthenticated-remote-code-execution-cve-2025-1974)

[中文版本 (version chinoise)](https://github.com/vulhub/vulhub/blob/master/ingress-nginx/CVE-2025-1974/README.zh-cn.md)

Ingress-NGINX est un contrôleur d'entrée pour Kubernetes qui utilise NGINX comme proxy inverse et équilibreur de charge.

La vulnérabilité « IngressNightmare » (CVE-2025-1974) provient d'une faille critique dans le contrôleur d'admission Ingress-NGINX, un mécanisme de sécurité essentiel de Kubernetes chargé de valider les ressources Ingress entrantes. Ce contrôleur est exposé sur le réseau sans authentification, ce qui permet aux attaquants de concevoir `AdmissionReview`des requêtes malveillantes et d'injecter des configurations non autorisées dans les ressources Ingress. Combiné à d'autres vulnérabilités (CVE-2025-24514, CVE-2025-1097 ou CVE-2025-1098), cela peut permettre l'exécution de code à distance.

Certaines chaînes exploitables sont connues :

- CVE-2025-1974 + CVE-2025-24514 : Exécution de code à distance via `auth-url`injection d’annotations
- CVE-2025-1974 + CVE-2025-1097 : Exécution de code à distance via `auth-tls-match-cn`une annotation
- CVE-2025-1974 + CVE-2025-1098 : Exécution de code à distance via l’exploitation de l’UID d’une image

Références :

- [https://www.wiz.io/blog/ingress-nginx-kubernetes-vulnerabilities](https://www.wiz.io/blog/ingress-nginx-kubernetes-vulnerabilities)
- [https://kubernetes.io/blog/2025/03/24/ingress-nginx-cve-2025-1974/](https://kubernetes.io/blog/2025/03/24/ingress-nginx-cve-2025-1974/)
- [https://github.com/yoshino-s/CVE-2025-1974](https://github.com/yoshino-s/CVE-2025-1974)
- [https://github.com/Clifford-prog/IngressNightmare-PoC](https://github.com/Clifford-prog/IngressNightmare-PoC)
- [https://github.com/kubernetes/ingress-nginx/blob/8c1ecd7655bd052a26e64d3361dede3096cd80c6/internal/ingress/controller/controller.go#L425](https://github.com/kubernetes/ingress-nginx/blob/8c1ecd7655bd052a26e64d3361dede3096cd80c6/internal/ingress/controller/controller.go#L425)