Vulnérabilité treouvées

warning[]=KRNL-5830|Reboot of system is most likely needed||text:reboot|
warning[]=FIRE-4512|iptables module(s) loaded, but no rules active|-|-|
warning[]=LOGG-2138|klogd is not running, which could lead to missing kernel messages in log files|-|-|

===== PORTS OUVERTS =====

===== VULNÉRABILITÉS CRITIQUES =====
|   After NULL UDP avahi packet DoS (CVE-2011-1002).
Suggestions (53):
  ----------------------------
  * Set a password on GRUB boot loader to prevent altering boot configuration (e.g. boot in single user mode without password) [BOOT-5122] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/BOOT-5122/

  * Determine runlevel and services at startup [BOOT-5180] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/BOOT-5180/

  * If not required, consider explicit disabling of core dump in /etc/security/limits.conf file [KRNL-5820] 
    - Related resources
      * Article: Understand and configure core dumps on Linux: https://linux-audit.com/software/understand-and-configure-core-dumps-work-on-linux/
      * Website: https://cisofy.com/lynis/controls/KRNL-5820/

  * Check PAM configuration, add rounds if applicable and expire passwords to encrypt with new values [AUTH-9229] 
    - Related resources
      * Article: Linux password security: hashing rounds: https://linux-audit.com/authentication/configure-the-minimum-password-length-on-linux-systems/
      * Website: https://cisofy.com/lynis/controls/AUTH-9229/

  * Configure password hashing rounds in /etc/login.defs [AUTH-9230] 
    - Related resources
      * Article: Linux password security: hashing rounds: https://linux-audit.com/authentication/configure-the-minimum-password-length-on-linux-systems/
      * Website: https://cisofy.com/lynis/controls/AUTH-9230/

  * Install a PAM module for password strength testing like pam_cracklib or pam_passwdqc or libpam-passwdqc [AUTH-9262] 
    - Related resources
      * Article: Configure minimum password length for Linux systems: https://linux-audit.com/configure-the-minimum-password-length-on-linux-systems/
      * Website: https://cisofy.com/lynis/controls/AUTH-9262/

  * When possible set expire dates for all password protected accounts [AUTH-9282] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/AUTH-9282/

  * Configure minimum password age in /etc/login.defs [AUTH-9286] 
    - Related resources
      * Article: Configure minimum password length for Linux systems: https://linux-audit.com/configure-the-minimum-password-length-on-linux-systems/
      * Website: https://cisofy.com/lynis/controls/AUTH-9286/

  * Configure maximum password age in /etc/login.defs [AUTH-9286] 
    - Related resources
      * Article: Configure minimum password length for Linux systems: https://linux-audit.com/configure-the-minimum-password-length-on-linux-systems/
      * Website: https://cisofy.com/lynis/controls/AUTH-9286/

  * Default umask in /etc/profile or /etc/profile.d/custom.sh could be more strict (e.g. 027) [AUTH-9328] 
    - Related resources
      * Article: Set default file permissions on Linux with umask: https://linux-audit.com/filesystems/file-permissions/set-default-file-permissions-with-umask/
      * Website: https://cisofy.com/lynis/controls/AUTH-9328/

  * Default umask in /etc/login.defs could not be found and defaults usually to 022, which could be more strict like 027 [AUTH-9328] 
    - Related resources
      * Article: Set default file permissions on Linux with umask: https://linux-audit.com/filesystems/file-permissions/set-default-file-permissions-with-umask/
      * Website: https://cisofy.com/lynis/controls/AUTH-9328/

  * Default umask in /etc/init.d/rc could be more strict like 027 [AUTH-9328] 
    - Related resources
      * Article: Set default file permissions on Linux with umask: https://linux-audit.com/filesystems/file-permissions/set-default-file-permissions-with-umask/
      * Website: https://cisofy.com/lynis/controls/AUTH-9328/

  * To decrease the impact of a full /home file system, place /home on a separate partition [FILE-6310] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/FILE-6310/

  * To decrease the impact of a full /tmp file system, place /tmp on a separate partition [FILE-6310] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/FILE-6310/

  * To decrease the impact of a full /var file system, place /var on a separate partition [FILE-6310] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/FILE-6310/

  * Check 4 files in /tmp which are older than 90 days [FILE-6354] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/FILE-6354/

  * Disable drivers like USB storage when not used, to prevent unauthorized storage or data theft [USB-1000] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/USB-1000/

  * Disable drivers like firewire storage when not used, to prevent unauthorized storage or data theft [STRG-1846] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/STRG-1846/

  * Check DNS configuration for the dns domain name [NAME-4028] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/NAME-4028/

  * Purge old/removed packages (3 found) with aptitude purge or dpkg --purge command. This will cleanup old configuration files, cron jobs and startup scripts. [PKGS-7346] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/PKGS-7346/

  * Install debsums utility for the verification of packages with known good database. [PKGS-7370] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/PKGS-7370/

  * Install package apt-show-versions for patch management purposes [PKGS-7394] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/PKGS-7394/

  * Consider using a tool to automatically apply upgrades [PKGS-7420] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/PKGS-7420/

  * Determine if protocol 'dccp' is really needed on this system [NETW-3200] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/NETW-3200/

  * Determine if protocol 'sctp' is really needed on this system [NETW-3200] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/NETW-3200/

  * Determine if protocol 'rds' is really needed on this system [NETW-3200] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/NETW-3200/

  * Determine if protocol 'tipc' is really needed on this system [NETW-3200] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/NETW-3200/

  * Disable the 'VRFY' command [MAIL-8820:disable_vrfy_command] 
    - Details  : disable_vrfy_command=no
    - Solution : run postconf -e disable_vrfy_command=yes to change the value
    - Related resources
      * Article: Postfix Hardening Guide for Security and Privacy: https://linux-audit.com/postfix-hardening-guide-for-security-and-privacy/
      * Website: https://cisofy.com/lynis/controls/MAIL-8820/

  * Install Apache mod_evasive to guard webserver against DoS/brute force attempts [HTTP-6640] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/HTTP-6640/

  * Install Apache mod_reqtimeout or mod_qos to guard webserver against Slowloris attacks [HTTP-6641] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/HTTP-6641/

  * Install Apache modsecurity to guard webserver against web application attacks [HTTP-6643] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/HTTP-6643/

  * Check if any syslog daemon is running and correctly configured. [LOGG-2130] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/LOGG-2130/

  * Although inetd is not running, make sure no services are enabled in /etc/inetd.conf, or remove inetd service [INSE-8006] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/INSE-8006/

  * If there are no xinetd services required, it is recommended that the daemon be removed [INSE-8100] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/INSE-8100/

  * Remove rsh client when it is not in use or replace with the more secure SSH package [INSE-8300] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/INSE-8300/

  * Remove the rsh-server package and replace with a more secure alternative like SSH [INSE-8304] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/INSE-8304/

  * Removing the telnet server package and replace with SSH when possible [INSE-8322] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/INSE-8322/

  * Removing the tftpd package decreases the risk of the accidental (or intentional) activation of tftp services [INSE-8320] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/INSE-8320/

  * Add a legal banner to /etc/issue, to warn unauthorized users [BANN-7126] 
    - Related resources
      * Article: The real purpose of login banners: https://linux-audit.com/the-real-purpose-of-login-banners-on-linux/
      * Website: https://cisofy.com/lynis/controls/BANN-7126/

  * Add legal banner to /etc/issue.net, to warn unauthorized users [BANN-7130] 
    - Related resources
      * Article: The real purpose of login banners: https://linux-audit.com/the-real-purpose-of-login-banners-on-linux/
      * Website: https://cisofy.com/lynis/controls/BANN-7130/

  * Enable process accounting [ACCT-9622] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/ACCT-9622/

  * Enable sysstat to collect accounting (no results) [ACCT-9626] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/ACCT-9626/

  * Enable auditd to collect audit information [ACCT-9628] 
    - Related resources
      * Article: Linux audit framework 101: basic rules for configuration: https://linux-audit.com/linux-audit-framework/linux-audit-framework-101-basic-rules-for-configuration/
      * Article: Monitoring Linux file access, changes and data modifications: https://linux-audit.com/monitoring-linux-file-access-changes-and-modifications/
      * Website: https://cisofy.com/lynis/controls/ACCT-9628/

  * Check available certificates for expiration [CRYP-7902] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/CRYP-7902/

  * Check output of aa-status [MACF-6208] 
    - Details  : /sys/kernel/security/apparmor/profiles
    - Solution : Run aa-status
    - Related resources
      * Article: AppArmor: https://linux-audit.com/security-frameworks/apparmor/
      * Website: https://cisofy.com/lynis/controls/MACF-6208/

  * Install a file integrity tool to monitor changes to critical and sensitive files [FINT-4350] 
    - Related resources
      * Article: Monitoring Linux file access, changes and data modifications: https://linux-audit.com/monitoring-linux-file-access-changes-and-modifications/
      * Article: Monitor for file changes on Linux: https://linux-audit.com/monitor-for-file-system-changes-on-linux/
      * Website: https://cisofy.com/lynis/controls/FINT-4350/

  * Determine if automation tools are present for system management [TOOL-5002] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/TOOL-5002/

  * Consider restricting file permissions [FILE-7524] 
    - Details  : See screen output or log file
    - Solution : Use chmod to change file permissions
    - Related resources
      * Website: https://cisofy.com/lynis/controls/FILE-7524/

  * Double check the permissions of home directories as some might be not strict enough. [HOME-9304] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/HOME-9304/

  * Double check the ownership of home directories as some might be incorrect. [HOME-9306] 
    - Related resources
      * Website: https://cisofy.com/lynis/controls/HOME-9306/

  * One or more sysctl values differ from the scan profile and could be tweaked [KRNL-6000] 
    - Solution : Change sysctl value or disable test (skip-test=KRNL-6000:<sysctl-key>)
    - Related resources
      * Article: Linux hardening with sysctl settings: https://linux-audit.com/linux-hardening-with-sysctl/
      * Article: Overview of sysctl options and values: https://linux-audit.com/kernel/sysctl/
      * Website: https://cisofy.com/lynis/controls/KRNL-6000/

  * Harden compilers like restricting access to root user only [HRDN-7222] 
    - Related resources
      * Article: Why remove compilers from your system?: https://linux-audit.com/software/why-remove-compilers-from-your-system/
      * Website: https://cisofy.com/lynis/controls/HRDN-7222/

  * Harden the system by installing at least one malware scanner, to perform periodic file system scans [HRDN-7230] 
    - Solution : Install a tool like rkhunter, chkrootkit, OSSEC, Wazuh
    - Related resources
      * Article: Antivirus for Linux: is it really needed?: https://linux-audit.com/malware/antivirus-for-linux-really-needed/
      * Article: Monitoring Linux Systems for Rootkits: https://linux-audit.com/monitoring-linux-systems-for-rootkits/
      * Website: https://cisofy.com/lynis/controls/HRDN-7230/