# Exécution de code à distance avant authentification dans CraftCMS ConditionsController (CVE-2023-41892)

[](https://github.com/vulhub/vulhub/tree/master/craftcms/CVE-2023-41892#craftcms-conditionscontroller-pre-auth-remote-code-execution-cve-2023-41892)

[中文版本 (version chinoise)](https://github.com/vulhub/vulhub/blob/master/craftcms/CVE-2023-41892/README.zh-cn.md)

Craft CMS est un système de gestion de contenu (CMS) flexible et convivial permettant de créer des expériences numériques personnalisées sur le web. Il offre aux utilisateurs une interface d'administration pour implémenter des sites web et configurer le CMS.

Une vulnérabilité présente dans les versions 4.4.0 à 4.4.14 de Craft CMS permet à des attaquants non authentifiés d'exécuter du code à distance `ConditionsController`. Cette vulnérabilité est due à une validation insuffisante des entrées dans la `beforeAction`méthode du contrôleur, ce qui peut être exploité pour créer des objets arbitraires et exécuter du code.

Références :

- [https://github.com/craftcms/cms/security/advisories/GHSA-4w8r-3xrw-v25g](https://github.com/craftcms/cms/security/advisories/GHSA-4w8r-3xrw-v25g)
- [https://blog.calif.io/p/craftcms-rce](https://blog.calif.io/p/craftcms-rce)
- [https://swarm.ptsecurity.com/exploiting-arbitrary-object-instantiations/](https://swarm.ptsecurity.com/exploiting-arbitrary-object-instantiations/)

# CraftCMS `register_argc_argv`permet l'exécution de code à distance (CVE-2024-56145)

[](https://github.com/vulhub/vulhub/tree/master/craftcms/CVE-2024-56145#craftcms-register_argc_argv-leads-to-remote-code-execution-cve-2024-56145)

[中文版本 (version chinoise)](https://github.com/vulhub/vulhub/blob/master/craftcms/CVE-2024-56145/README.zh-cn.md)

CraftCMS est un système de gestion de contenu basé sur PHP permettant de créer des sites web et des applications.

Les versions de CraftCMS antérieures à 5.5.2 et 4.13.2 sont vulnérables à l'exécution de code à distance si le paramètre PHP `register_argc_argv`est activé. Lorsque `register_argc_argv`ce paramètre est activé, CraftCMS interprète incorrectement les éléments de configuration de la requête HTTP, permettant ainsi à un attaquant de contrôler les fichiers de modèles `--templatesPath`via l'injection de dépendances (template injection).

Référence:

- [https://github.com/craftcms/cms/security/advisories/GHSA-2p6p-9rc9-62j9](https://github.com/craftcms/cms/security/advisories/GHSA-2p6p-9rc9-62j9)
- [https://www.assetnote.io/resources/research/how-an-obscure-php-footgun-led-to-rce-in-craft-cms](https://www.assetnote.io/resources/research/how-an-obscure-php-footgun-led-to-rce-in-craft-cms)