# Gradio File Path Traversal (CVE-2023-51449)

[](https://github.com/vulhub/vulhub/tree/master/gradio/CVE-2023-51449#gradio-file-path-traversal-cve-2023-51449)

[中文版本(Chinese version)](https://github.com/vulhub/vulhub/blob/master/gradio/CVE-2023-51449/README.zh-cn.md)

Gradio is a Python library that allows users to quickly build visual web interfaces for machine learning models without writing any front-end code.

In Gradio versions 4.11 and below, when authentication is not enabled, an attacker who knows the file path can use a public URL to access arbitrary files on the server running the Gradio application.

References:

- [gradio-app/gradio#6833](https://github.com/gradio-app/gradio/pull/6833)
- [https://github.com/gradio-app/gradio/security/advisories/GHSA-6qm2-wpxq-7qh2](https://github.com/gradio-app/gradio/security/advisories/GHSA-6qm2-wpxq-7qh2)

# Gradio Arbitrary File Read (CVE-2024-1561)

[](https://github.com/vulhub/vulhub/tree/master/gradio/CVE-2024-1561#gradio-arbitrary-file-read-cve-2024-1561)

[中文版本(Chinese version)](https://github.com/vulhub/vulhub/blob/master/gradio/CVE-2024-1561/README.zh-cn.md)

Gradio is a Python library that enables users to rapidly build web-based interfaces for machine learning models without writing any front-end code.

In Gradio versions prior to 4.13, the `component_server` endpoint allows attackers to invoke arbitrary methods of the `Component` class. By abusing the `move_resource_to_block_cache` method, an attacker can copy any file from the server to a temporary directory and then retrieve its contents, leading to arbitrary file read.

References:

- [gradio-app/gradio#6884](https://github.com/gradio-app/gradio/pull/6884)
- [https://nvd.nist.gov/vuln/detail/CVE-2024-1561](https://nvd.nist.gov/vuln/detail/CVE-2024-1561)